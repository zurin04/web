import React from "react";
import { Helmet } from "react-helmet";
import { useAuth } from "@/hooks/use-auth";
import MemberList from "@/components/member-list";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { UserRoundX, ShieldAlert } from "lucide-react";
import { Link, Redirect } from "wouter";
import MainLayout from "@/components/layout/main-layout";

export default function MembersPage() {
  const { user } = useAuth();

  // If not logged in, show auth required
  if (!user) {
    return (
      <MainLayout>
        <div className="container mx-auto py-12">
          <Alert variant="destructive">
            <UserRoundX className="h-4 w-4" />
            <AlertTitle>Authentication Required</AlertTitle>
            <AlertDescription>
              You need to be logged in to access this page.
            </AlertDescription>
            <div className="mt-4">
              <Button asChild>
                <Link href="/auth">Login or Register</Link>
              </Button>
            </div>
          </Alert>
        </div>
      </MainLayout>
    );
  }
  
  // If user is not an admin, show access denied
  if (!user.isAdmin) {
    return (
      <MainLayout>
        <Helmet>
          <title>Access Denied | AirdropVerse</title>
          <meta name="description" content="Access denied - admin only page" />
        </Helmet>
        
        <div className="container mx-auto py-12">
          <Alert variant="destructive">
            <ShieldAlert className="h-4 w-4" />
            <AlertTitle>Access Denied</AlertTitle>
            <AlertDescription>
              Only administrators can access the member management page.
            </AlertDescription>
            <div className="mt-4">
              <Button asChild variant="outline">
                <Link href="/">Return to Home</Link>
              </Button>
            </div>
          </Alert>
        </div>
      </MainLayout>
    );
  }
  
  return (
    <MainLayout>
      <Helmet>
        <title>Member Directory | AirdropVerse</title>
        <meta name="description" content="Browse and manage the directory of AirdropVerse members, creators, and admins." />
      </Helmet>
      
      <div className="container mx-auto py-8">
        <h1 className="text-3xl font-bold mb-8">Member Directory</h1>
        <MemberList />
      </div>
    </MainLayout>
  );
}