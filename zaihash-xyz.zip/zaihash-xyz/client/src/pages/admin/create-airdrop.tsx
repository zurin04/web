import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";
import { InsertAirdrops, Category } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, Loader2 } from "lucide-react";
import { AirdropStepEditor, AirdropStep } from "@/components/admin/airdrop-step-editor";

// Function to convert steps to HTML format
const formatStepsToHTML = (steps: AirdropStep[]) => {
  const htmlSteps = steps.map((step, index) => {
    let stepHtml = `<div class="step">
<h3>Step ${index + 1}</h3>
<p>${step.content}</p>`;
    
    if (step.imageUrl) {
      stepHtml += `\n<img src="${step.imageUrl}" alt="Step ${index + 1}" />`;
    }
    
    stepHtml += '\n</div>';
    return stepHtml;
  });

  return htmlSteps.join('\n\n');
};

// Function to try parsing existing HTML steps into the step format
const tryParseExistingSteps = (html: string): AirdropStep[] => {
  try {
    // Create a simple parser for the HTML format used
    const stepRegex = /<div class="step">([\s\S]*?)<\/div>/g;
    const contentRegex = /<p>([\s\S]*?)<\/p>/;
    const imageRegex = /<img src="([\s\S]*?)" alt="[^"]*" \/>/;
    
    const steps: AirdropStep[] = [];
    let match;
    
    while ((match = stepRegex.exec(html)) !== null) {
      const stepHtml = match[1];
      
      // Extract content
      const contentMatch = contentRegex.exec(stepHtml);
      const content = contentMatch ? contentMatch[1].trim() : '';
      
      // Extract image if present
      const imageMatch = imageRegex.exec(stepHtml);
      const imageUrl = imageMatch ? imageMatch[1] : undefined;
      
      steps.push({ content, imageUrl });
    }
    
    return steps.length > 0 ? steps : [{ content: html, imageUrl: undefined }];
  } catch (error) {
    // If parsing fails, return a single step with all the content
    console.error('Error parsing HTML steps:', error);
    return [{ content: html, imageUrl: undefined }];
  }
};

export default function CreateAirdrop() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState<Partial<InsertAirdrops>>({
    title: "",
    description: "",
    tags: [],
    link: "",
    status: "active",
    category_id: undefined,
  });
  
  const [currentTag, setCurrentTag] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  // Fetch categories for the dropdown
  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  const createAirdropMutation = useMutation({
    mutationFn: async (data: InsertAirdrops) => {
      const res = await apiRequest("POST", "/api/admin/airdrops", data);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/airdrops"] });
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops"] });
      toast({
        title: "Airdrop created",
        description: "Your airdrop tutorial has been successfully created.",
      });
      // Navigate to admin dashboard, which is just "/admin"
      navigate("/admin");
    },
    onError: (error: Error) => {
      toast({
        title: "Error creating airdrop",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title?.trim()) {
      newErrors.title = "Title is required";
    }
    
    if (!formData.description?.trim()) {
      newErrors.description = "Description is required";
    }
    
    if (!formData.tags || formData.tags.length === 0) {
      newErrors.tags = "At least one tag is required";
    }
    
    if (formData.link && !isValidUrl(formData.link)) {
      newErrors.link = "Please enter a valid URL";
    }
    
    if (!formData.category_id) {
      newErrors.category_id = "Please select a category";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const isValidUrl = (string: string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  };
  
  const handleAddTag = () => {
    if (currentTag.trim() && !formData.tags?.includes(currentTag.trim())) {
      setFormData({
        ...formData,
        tags: [...(formData.tags || []), currentTag.trim()],
      });
      setCurrentTag("");
    }
  };
  
  const handleRemoveTag = (tag: string) => {
    setFormData({
      ...formData,
      tags: formData.tags?.filter(t => t !== tag) || [],
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    // Don't pass created_at and updated_at - they have database defaults
    createAirdropMutation.mutate({
      title: formData.title || "",
      description: formData.description || "",
      tags: formData.tags || [],
      link: formData.link || "",
      status: formData.status || "active",
      views: 0,
      category_id: formData.category_id,
      posted_by: user?.username || "admin",
    });
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Helmet>
        <title>Create Airdrop - Admin Dashboard</title>
        <meta name="description" content="Create a new airdrop tutorial or task for users." />
      </Helmet>
      
      <Sidebar />
      
      <main className="flex-1 p-6 md:p-10">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => navigate("/admin")}
              className="mb-4"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              Back to Dashboard
            </Button>
            
            <h1 className="text-3xl font-bold text-white">Create New Airdrop</h1>
            <p className="text-gray-400 mt-2">
              Add a new airdrop tutorial or task for users to complete.
            </p>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Airdrop Details</CardTitle>
              <CardDescription>Fill in the details for the new airdrop tutorial</CardDescription>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input 
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="e.g., ZetaChain Testnet Airdrop"
                  />
                  {errors.title && (
                    <p className="text-destructive text-sm">{errors.title}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Tutorial Steps</Label>
                  <AirdropStepEditor
                    steps={
                      // If formData.description already exists, try to parse it, otherwise start with an empty array
                      formData.description 
                        ? tryParseExistingSteps(formData.description) 
                        : []
                    }
                    onChange={(steps) => {
                      const formattedHTML = formatStepsToHTML(steps);
                      setFormData({ ...formData, description: formattedHTML });
                    }}
                  />
                  {errors.description && (
                    <p className="text-destructive text-sm">{errors.description}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label>Tags</Label>
                  <div className="flex space-x-2">
                    <Input 
                      value={currentTag}
                      onChange={(e) => setCurrentTag(e.target.value)}
                      placeholder="Add a tag"
                      className="flex-1"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddTag();
                        }
                      }}
                    />
                    <Button 
                      type="button" 
                      variant="secondary"
                      onClick={handleAddTag}
                    >
                      Add Tag
                    </Button>
                  </div>
                  {errors.tags && (
                    <p className="text-destructive text-sm">{errors.tags}</p>
                  )}
                  <div className="flex flex-wrap gap-2 mt-2">
                    {formData.tags?.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="gap-1">
                        {tag}
                        <button 
                          type="button" 
                          className="ml-1 hover:text-destructive focus:outline-none"
                          onClick={() => handleRemoveTag(tag)}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                          <span className="sr-only">Remove tag</span>
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="link">External Link (Optional)</Label>
                  <Input 
                    id="link"
                    value={formData.link}
                    onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                    placeholder="https://example.com/airdrop"
                  />
                  {errors.link && (
                    <p className="text-destructive text-sm">{errors.link}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select 
                    value={formData.category_id?.toString()} 
                    onValueChange={(value) => setFormData({ ...formData, category_id: parseInt(value, 10) })}
                  >
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categoriesLoading ? (
                        <div className="flex items-center justify-center p-2">
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          <span>Loading categories...</span>
                        </div>
                      ) : categories && categories.length > 0 ? (
                        categories.map(category => (
                          <SelectItem key={category.id} value={category.id.toString()}>
                            {category.name}
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="no-categories" disabled>
                          No categories available
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                  {errors.category_id && (
                    <p className="text-destructive text-sm">{errors.category_id}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select 
                    defaultValue={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {createAirdropMutation.error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      {createAirdropMutation.error.message}
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => navigate("/admin")}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createAirdropMutation.isPending}
                >
                  {createAirdropMutation.isPending ? "Creating..." : "Create Airdrop"}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </main>
    </div>
  );
}
