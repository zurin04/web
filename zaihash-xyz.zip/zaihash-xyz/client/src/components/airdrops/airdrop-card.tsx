import { useState } from "react";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Airdrops } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

interface AirdropCardProps {
  airdrop: Airdrops;
}

export default function AirdropCard({ airdrop }: AirdropCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isSaved, setIsSaved] = useState(user?.saved_tasks?.includes(airdrop.id) || false);
  
  const saveTaskMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/airdrops/${airdrop.id}/save`, {});
      return res.json();
    },
    onSuccess: () => {
      setIsSaved(!isSaved);
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: isSaved ? "Airdrop removed from saved" : "Airdrop saved",
        description: isSaved 
          ? "This airdrop has been removed from your saved list." 
          : "This airdrop has been added to your saved list.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  const handleSave = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to save airdrops.",
        variant: "destructive",
      });
      return;
    }
    saveTaskMutation.mutate();
  };

  // Format date to relative time (e.g., "2 days ago")
  const getRelativeTime = (dateInput: string | Date) => {
    const date = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) return "just now";
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} min ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} hours ago`;
    if (diffInSeconds < 2592000) return `${Math.floor(diffInSeconds / 86400)} days ago`;
    if (diffInSeconds < 31536000) return `${Math.floor(diffInSeconds / 2592000)} months ago`;
    return `${Math.floor(diffInSeconds / 31536000)} years ago`;
  };

  // Get first letter for avatar
  const firstLetter = airdrop.title.charAt(0).toUpperCase();
  
  // Get background color based on the first letter
  const getBackgroundColor = () => {
    const colors = ["bg-blue-900", "bg-green-900", "bg-purple-900", "bg-red-900", "bg-yellow-900", "bg-teal-900"];
    const index = firstLetter.charCodeAt(0) % colors.length;
    return colors[index];
  };
  
  // Get text color based on background
  const getTextColor = () => {
    const colors = ["text-blue-300", "text-green-300", "text-purple-300", "text-red-300", "text-yellow-300", "text-teal-300"];
    const index = firstLetter.charCodeAt(0) % colors.length;
    return colors[index];
  };

  return (
    <div className="task-card bg-background rounded-xl overflow-hidden shadow-lg border border-gray-800">
      <div className="p-5">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center">
            <div className={`w-10 h-10 ${getBackgroundColor()} rounded-full flex items-center justify-center mr-3`}>
              <span className={`font-bold ${getTextColor()}`}>{firstLetter}</span>
            </div>
            <div>
              <h3 className="font-bold text-white text-lg">{airdrop.title}</h3>
              <div className="flex items-center mt-1 flex-wrap gap-1">
                {airdrop.tags?.map((tag, index) => {
                  // Get tag specific colors
                  const getTagColors = () => {
                    const tagColorMap: Record<string, { bg: string, text: string }> = {
                      "Testnet": { bg: "bg-blue-900", text: "text-blue-200" },
                      "DeFi": { bg: "bg-purple-900", text: "text-purple-200" },
                      "Layer 2": { bg: "bg-green-900", text: "text-green-200" },
                      "NFT": { bg: "bg-yellow-900", text: "text-yellow-200" },
                      "Quest": { bg: "bg-pink-900", text: "text-pink-200" },
                      "Layer 1": { bg: "bg-teal-900", text: "text-teal-200" }
                    };
                    
                    return tagColorMap[tag] || { bg: "bg-gray-800", text: "text-gray-200" };
                  };
                  
                  const { bg, text } = getTagColors();
                  
                  return (
                    <Badge 
                      key={index} 
                      className={`${bg} ${text} border-none`}
                    >
                      {tag}
                    </Badge>
                  );
                })}
              </div>
            </div>
          </div>
          <div className="flex flex-col items-end">
            <button 
              className={`${isSaved ? "text-primary" : "text-gray-400 hover:text-white"}`}
              onClick={handleSave}
              disabled={saveTaskMutation.isPending}
            >
              {isSaved ? (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z" />
                </svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                </svg>
              )}
            </button>
            <span className="text-xs text-gray-500 mt-1">{getRelativeTime(airdrop.created_at)}</span>
          </div>
        </div>
        
        {/* Potential Profit Display */}
        {airdrop.potential_profit && (
          <div className="mb-3 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
            </svg>
            <span className="text-green-500 font-semibold text-sm">
              Potential Profit: {airdrop.potential_profit}
            </span>
          </div>
        )}
        <p className="text-gray-300 text-sm mb-4">
          {airdrop.description.length > 150
            ? airdrop.description.substring(0, 150).replace(/<[^>]*>?/gm, '') + "..."
            : airdrop.description.replace(/<[^>]*>?/gm, '')}
        </p>
        <div className="flex justify-between items-center">
          <div className="flex flex-col text-gray-400 text-sm">
            <div className="flex items-center mb-1">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
              </svg>
              {airdrop.views} views
            </div>
            {airdrop.posted_by && (
              <div className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
                <span className="text-primary-foreground">by {airdrop.posted_by}</span>
              </div>
            )}
          </div>
          <Link to={`/airdrop/${airdrop.id}`} className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-9 px-3">
            View Tutorial
          </Link>
        </div>
      </div>
    </div>
  );
}
