import { useLocation, Link } from "wouter";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Category, SiteSettings } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { useMobile } from "@/hooks/use-mobile";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

export default function Sidebar() {
  const [location] = useLocation();
  const isMobile = useMobile();
  const [isOpen, setIsOpen] = useState(false);
  const [categoriesOpen, setCategoriesOpen] = useState(false);
  const { user, logoutMutation } = useAuth();

  // Fetch categories for the navigation
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  // Fetch site settings for logo and site name
  const { data: siteSettings } = useQuery<SiteSettings>({
    queryKey: ["/api/site-settings"],
  });

  const isActive = (path: string) => {
    // Check if the path is exactly matching or if it's a category path and the current location is for that category
    if (location === path) return true;
    
    // For category paths, check if we're on a specific category page
    if (path.startsWith('/airdrops/category/') && location.startsWith('/airdrops/category/')) {
      const categoryId = path.split('/').pop();
      const currentCategoryId = location.split('/').pop();
      return categoryId === currentCategoryId;
    }
    
    return false;
  };

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const toggleCategories = () => {
    setCategoriesOpen(!categoriesOpen);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <aside className="w-full md:w-64 bg-card shadow-lg md:min-h-screen">
      <div className="p-4 flex items-center justify-between md:justify-center border-b border-border">
        <div className="flex items-center space-x-2">
          {siteSettings?.logo_url ? (
            <img 
              src={siteSettings.logo_url} 
              alt="Logo" 
              className="h-8 w-auto object-contain" 
            />
          ) : (
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
              </svg>
            </div>
          )}
          <h1 className="text-xl font-bold text-white">{siteSettings?.site_name || "AirdropHub"}</h1>
        </div>
        <button 
          className="md:hidden text-gray-400 hover:text-white" 
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>
      
      <nav className={`${isMobile && !isOpen ? "hidden" : "block"} p-4`}>
        <ul className="space-y-2">
          <li>
            <Link to="/" className={`flex items-center space-x-2 p-2 rounded-lg ${isActive("/") ? "bg-primary text-white" : "text-gray-300 hover:bg-muted transition-colors"}`}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                </svg>
                <span>Home</span>
            </Link>
          </li>
          <li>
            <Link to="/airdrops" className={`flex items-center space-x-2 p-2 rounded-lg ${isActive("/airdrops") ? "bg-primary text-white" : "text-gray-300 hover:bg-muted transition-colors"}`}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13l-3 3m0 0l-3-3m3 3V8m0 13a9 9 0 110-18 9 9 0 010 18z" />
                </svg>
                <span>All Airdrops</span>
            </Link>
          </li>
          
          {/* Categories Section */}
          <li>
            <Collapsible
              open={categoriesOpen}
              onOpenChange={setCategoriesOpen}
              className="w-full"
            >
              <CollapsibleTrigger asChild>
                <button className="flex items-center space-x-2 p-2 rounded-lg w-full text-left text-gray-300 hover:bg-muted transition-colors">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                  </svg>
                  <span>Categories</span>
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    className={`h-4 w-4 ml-auto transition-transform ${categoriesOpen ? 'transform rotate-180' : ''}`} 
                    fill="none" 
                    viewBox="0 0 24 24" 
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>
              </CollapsibleTrigger>
              <CollapsibleContent className="space-y-1 mt-1 pl-7">
                {categories.map(category => (
                  <Link
                    key={category.id}
                    to={`/airdrops/category/${category.id}`}
                    className={`block p-2 rounded-lg text-sm ${
                      isActive(`/airdrops/category/${category.id}`) 
                        ? "bg-primary text-white" 
                        : "text-gray-400 hover:text-gray-300 hover:bg-muted/50 transition-colors"
                    }`}
                  >
                    {category.name}
                  </Link>
                ))}
                {categories.length === 0 && (
                  <div className="text-sm text-gray-500 p-2">No categories available</div>
                )}
              </CollapsibleContent>
            </Collapsible>
          </li>

          {/* Creator links - shown only to creators and admins */}
          {(user?.isCreator || user?.isAdmin) && (
            <>
              <li className="pt-4 mt-4 border-t border-gray-700">
                <h3 className="text-xs uppercase text-gray-500 font-medium mb-2 px-2">Creator</h3>
              </li>
              <li>
                <Link to="/create-airdrop" className={`flex items-center space-x-2 p-2 rounded-lg ${isActive("/create-airdrop") ? "bg-primary text-white" : "text-gray-300 hover:bg-muted transition-colors"}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                    </svg>
                    <span>Post New Airdrop</span>
                </Link>
              </li>
            </>
          )}
          
          {/* Admin links - only shown to admin users */}
          {user?.isAdmin && (
            <>
              <li className="pt-4 mt-4 border-t border-gray-700">
                <h3 className="text-xs uppercase text-gray-500 font-medium mb-2 px-2">Admin</h3>
              </li>
              <li>
                <Link to="/admin" className={`flex items-center space-x-2 p-2 rounded-lg ${isActive("/admin") ? "bg-primary text-white" : "text-gray-300 hover:bg-muted transition-colors"}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    <span>Admin Dashboard</span>
                </Link>
              </li>
              <li>
                <Link to="/admin/creator-applications" className={`flex items-center space-x-2 p-2 rounded-lg ${isActive("/admin/creator-applications") ? "bg-primary text-white" : "text-gray-300 hover:bg-muted transition-colors"}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    <span>Creator Applications</span>
                </Link>
              </li>
            </>
          )}
          
          {/* Authentication links */}
          <li className="pt-4 mt-4 border-t border-gray-700">
            {user ? (
              <div className="space-y-2">
                <div className="px-2 py-1 text-sm text-gray-400">
                  Logged in as <span className="font-medium text-gray-300">{user.username}</span>
                </div>
                <Link to="/profile" className={`flex items-center space-x-2 p-2 rounded-lg mb-2 ${isActive("/profile") ? "bg-primary text-white" : "text-gray-300 hover:bg-muted transition-colors"}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
                    <circle cx="12" cy="7" r="4" />
                  </svg>
                  <span>My Profile</span>
                </Link>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={handleLogout}
                  disabled={logoutMutation.isPending}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                  </svg>
                  Logout
                </Button>
              </div>
            ) : (
              <Link to="/auth" className={`flex items-center space-x-2 p-2 rounded-lg ${isActive("/auth") ? "bg-primary text-white" : "text-gray-300 hover:bg-muted transition-colors"}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1" />
                  </svg>
                  <span>Login / Register</span>
              </Link>
            )}
          </li>
        </ul>
      </nav>
    </aside>
  );
}
