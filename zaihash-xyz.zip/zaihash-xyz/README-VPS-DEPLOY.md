# VPS Deployment Guide - Crypto Airdrop Platform

## One-Click Deployment

Deploy your crypto airdrop platform to any VPS with a single command:

```bash
# Basic deployment (HTTP only)
curl -fsSL https://raw.githubusercontent.com/[your-repo]/main/vps-deploy.sh | sudo bash

# With custom domain and SSL
curl -fsSL https://raw.githubusercontent.com/[your-repo]/main/vps-deploy.sh | sudo bash -s your-domain.com
```

## VPS Requirements

### Minimum Specifications
- **OS**: Ubuntu 20.04+ or Debian 11+
- **RAM**: 2GB (4GB recommended)
- **Storage**: 20GB SSD
- **Network**: Public IP address
- **CPU**: 1 vCPU (2+ recommended)

### Supported VPS Providers
- DigitalOcean
- Linode
- Vultr
- AWS EC2
- Google Cloud Platform
- Microsoft Azure
- Hetzner
- OVH
- Any Ubuntu/Debian VPS

## What Gets Installed

### System Components
- **Node.js 20**: Latest LTS version with npm
- **PostgreSQL**: Database server with optimized configuration
- **Nginx**: Reverse proxy with security headers and rate limiting
- **PM2**: Process manager with clustering and auto-restart
- **UFW Firewall**: Security with SSH, HTTP, and HTTPS access
- **Certbot**: SSL certificate management (if domain provided)

### Application Setup
- **Automatic Configuration**: Environment variables and database setup
- **Security**: Secure passwords, user isolation, file permissions
- **Monitoring**: Health checks, logging, and error tracking
- **Management**: Command-line tools for common operations

## Manual Setup (Alternative)

If you prefer manual setup or need customization:

### 1. Prepare VPS
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install dependencies
sudo apt install -y curl wget git unzip software-properties-common
```

### 2. Install Node.js
```bash
# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2
sudo npm install -g pm2
```

### 3. Install PostgreSQL
```bash
# Install PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Start and enable
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### 4. Install Nginx
```bash
# Install Nginx
sudo apt install -y nginx

# Start and enable
sudo systemctl start nginx
sudo systemctl enable nginx
```

### 5. Setup Application
```bash
# Create app user and directory
sudo useradd -r -s /bin/bash -d /opt/crypto-airdrop -m crypto
sudo mkdir -p /opt/crypto-airdrop
cd /opt/crypto-airdrop

# Clone repository
sudo git clone https://github.com/[your-repo]/crypto-airdrop.git .

# Install dependencies
sudo -u crypto npm install
sudo -u crypto npm run build
```

### 6. Configure Database
```bash
# Create database and user
sudo -u postgres psql << 'EOF'
CREATE DATABASE crypto_airdrop_db;
CREATE USER crypto_user WITH ENCRYPTED PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE crypto_airdrop_db TO crypto_user;
ALTER USER crypto_user CREATEDB;
\q
EOF
```

### 7. Configure Environment
```bash
# Create environment file
sudo tee /opt/crypto-airdrop/.env << 'EOF'
NODE_ENV=production
PORT=5000
DATABASE_URL=postgresql://crypto_user:your_secure_password@localhost:5432/crypto_airdrop_db
SESSION_SECRET=your_session_secret_here
EOF

# Set permissions
sudo chown crypto:crypto /opt/crypto-airdrop/.env
sudo chmod 600 /opt/crypto-airdrop/.env
```

## Management Commands

After deployment, use these commands to manage your application:

```bash
# Application control
crypto-manage start      # Start the application
crypto-manage stop       # Stop the application
crypto-manage restart    # Restart the application
crypto-manage status     # Check application status
crypto-manage logs       # View application logs

# Maintenance
crypto-manage update     # Update application from git
crypto-manage backup     # Create database backup
```

## Configuration Files

### PM2 Ecosystem (`/opt/crypto-airdrop/ecosystem.config.js`)
```javascript
module.exports = {
  apps: [{
    name: 'crypto-airdrop',
    script: 'server/index.js',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    // ... additional PM2 configuration
  }]
};
```

### Nginx Configuration (`/etc/nginx/sites-available/crypto-airdrop`)
- Reverse proxy to Node.js application
- Security headers and rate limiting
- Gzip compression
- SSL/TLS configuration (if domain provided)

### Environment Variables (`/opt/crypto-airdrop/.env`)
- `NODE_ENV=production`
- `PORT=5000`
- `DATABASE_URL=postgresql://...`
- `SESSION_SECRET=...`

## SSL/HTTPS Setup

### Automatic (with domain)
SSL is automatically configured when you provide a domain:
```bash
curl -fsSL https://raw.githubusercontent.com/[repo]/main/vps-deploy.sh | sudo bash -s your-domain.com
```

### Manual SSL Setup
```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d your-domain.com

# Test auto-renewal
sudo certbot renew --dry-run
```

## Security Features

### Firewall Configuration
- SSH access (port 22)
- HTTP access (port 80)
- HTTPS access (port 443)
- All other ports blocked by default

### Application Security
- Non-root user execution
- Secure session management
- Input validation and sanitization
- Rate limiting on API endpoints
- Security headers via Nginx

### Database Security
- Dedicated database user with limited privileges
- Encrypted password storage
- Connection string protection

## Monitoring and Logging

### Application Logs
```bash
# PM2 logs
crypto-manage logs

# System logs
sudo journalctl -u nginx
sudo journalctl -u postgresql
```

### Health Monitoring
- Built-in health check endpoint: `/health`
- PM2 automatic restart on crashes
- Nginx upstream health monitoring

## Backup and Recovery

### Database Backup
```bash
# Create backup
crypto-manage backup

# Manual backup
sudo -u postgres pg_dump crypto_airdrop_db > backup.sql
```

### Full System Backup
```bash
# Backup application files
sudo tar -czf crypto-airdrop-$(date +%Y%m%d).tar.gz /opt/crypto-airdrop

# Backup database
sudo -u postgres pg_dump crypto_airdrop_db > crypto-db-$(date +%Y%m%d).sql
```

### Recovery
```bash
# Restore database
sudo -u postgres psql crypto_airdrop_db < backup.sql

# Restore application
sudo tar -xzf crypto-airdrop-backup.tar.gz -C /
sudo chown -R crypto:crypto /opt/crypto-airdrop
```

## Updating the Application

### Automatic Update
```bash
crypto-manage update
```

### Manual Update
```bash
cd /opt/crypto-airdrop
sudo -u crypto git pull
sudo -u crypto npm install
sudo -u crypto npm run build
sudo -u crypto pm2 restart crypto-airdrop
```

## Troubleshooting

### Application Won't Start
```bash
# Check PM2 status
crypto-manage status

# Check logs
crypto-manage logs

# Check system resources
free -h
df -h
```

### Database Connection Issues
```bash
# Test database connection
sudo -u postgres psql crypto_airdrop_db -c "SELECT version();"

# Check PostgreSQL status
sudo systemctl status postgresql
```

### Nginx Issues
```bash
# Test Nginx configuration
sudo nginx -t

# Check Nginx status
sudo systemctl status nginx

# Check Nginx logs
sudo tail -f /var/log/nginx/error.log
```

### SSL Certificate Issues
```bash
# Check certificate status
sudo certbot certificates

# Renew certificate
sudo certbot renew

# Test renewal
sudo certbot renew --dry-run
```

## Performance Optimization

### PM2 Configuration
- Cluster mode for multiple CPU cores
- Automatic restarts on failure
- Memory limit protection
- Log rotation

### Nginx Optimization
- Gzip compression enabled
- Static file caching
- Rate limiting protection
- Keep-alive connections

### Database Optimization
- Connection pooling
- Optimized PostgreSQL configuration
- Regular maintenance commands

## Support and Maintenance

### Regular Maintenance Tasks
```bash
# Update system packages
sudo apt update && sudo apt upgrade

# Restart application
crypto-manage restart

# Check disk space
df -h

# Check memory usage
free -h

# View system logs
sudo journalctl --since "1 hour ago"
```

### Getting Help
1. Check application logs: `crypto-manage logs`
2. Check system status: `crypto-manage status`
3. Review this documentation
4. Contact support with error logs and system information

---

**Note**: Replace `[your-repo]` with your actual GitHub repository path before deployment.