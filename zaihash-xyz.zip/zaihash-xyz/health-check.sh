#!/bin/bash

# Health Check Script for Crypto Airdrop Platform
# Run this script to verify all services are running correctly

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() { echo -e "${BLUE}[INFO]${NC} $1"; }
print_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }

APP_DIR="/opt/crypto-airdrop"
APP_USER="crypto"

echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║                        Crypto Airdrop Platform Health Check                 ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check system resources
check_system_resources() {
    print_status "Checking system resources..."
    
    # Memory check
    memory_usage=$(free | grep Mem | awk '{printf "%.1f", $3/$2 * 100.0}')
    if (( $(echo "$memory_usage > 90" | bc -l) )); then
        print_error "High memory usage: ${memory_usage}%"
    elif (( $(echo "$memory_usage > 75" | bc -l) )); then
        print_warning "Moderate memory usage: ${memory_usage}%"
    else
        print_success "Memory usage: ${memory_usage}%"
    fi
    
    # Disk space check
    disk_usage=$(df / | tail -1 | awk '{print $5}' | sed 's/%//')
    if (( disk_usage > 90 )); then
        print_error "High disk usage: ${disk_usage}%"
    elif (( disk_usage > 75 )); then
        print_warning "Moderate disk usage: ${disk_usage}%"
    else
        print_success "Disk usage: ${disk_usage}%"
    fi
    
    # Load average check
    load_avg=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
    print_success "Load average: $load_avg"
    
    echo ""
}

# Check PostgreSQL
check_postgresql() {
    print_status "Checking PostgreSQL..."
    
    if systemctl is-active --quiet postgresql; then
        print_success "PostgreSQL service is running"
        
        # Test database connection
        if sudo -u postgres psql -d crypto_airdrop_db -c "SELECT 1;" >/dev/null 2>&1; then
            print_success "Database connection successful"
        else
            print_error "Database connection failed"
        fi
        
        # Check database size
        db_size=$(sudo -u postgres psql -d crypto_airdrop_db -t -c "SELECT pg_size_pretty(pg_database_size('crypto_airdrop_db'));" | xargs)
        print_success "Database size: $db_size"
    else
        print_error "PostgreSQL service is not running"
    fi
    
    echo ""
}

# Check Nginx
check_nginx() {
    print_status "Checking Nginx..."
    
    if systemctl is-active --quiet nginx; then
        print_success "Nginx service is running"
        
        # Test configuration
        if nginx -t >/dev/null 2>&1; then
            print_success "Nginx configuration is valid"
        else
            print_error "Nginx configuration has errors"
        fi
        
        # Check if listening on ports
        if netstat -tlnp | grep :80 >/dev/null; then
            print_success "Nginx listening on port 80"
        else
            print_warning "Nginx not listening on port 80"
        fi
        
        if netstat -tlnp | grep :443 >/dev/null; then
            print_success "Nginx listening on port 443 (HTTPS)"
        else
            print_warning "Nginx not listening on port 443 (HTTPS not configured)"
        fi
    else
        print_error "Nginx service is not running"
    fi
    
    echo ""
}

# Check Application (PM2)
check_application() {
    print_status "Checking Application (PM2)..."
    
    if command -v pm2 >/dev/null 2>&1; then
        print_success "PM2 is installed"
        
        # Check if application is running
        if sudo -u "$APP_USER" pm2 list | grep -q "crypto-airdrop"; then
            status=$(sudo -u "$APP_USER" pm2 list | grep "crypto-airdrop" | awk '{print $10}')
            if [[ "$status" == "online" ]]; then
                print_success "Application is running"
                
                # Check application health endpoint
                if curl -f http://localhost:5000/health >/dev/null 2>&1; then
                    print_success "Application health check passed"
                else
                    print_warning "Application health check failed"
                fi
                
                # Check if application responds to requests
                if curl -f http://localhost:5000 >/dev/null 2>&1; then
                    print_success "Application responds to requests"
                else
                    print_warning "Application not responding to requests"
                fi
            else
                print_error "Application status: $status"
            fi
        else
            print_error "Application not found in PM2"
        fi
    else
        print_error "PM2 not installed"
    fi
    
    echo ""
}

# Check Network Connectivity
check_network() {
    print_status "Checking Network Connectivity..."
    
    # Check if server is accessible externally
    server_ip=$(curl -s ifconfig.me 2>/dev/null || echo "unknown")
    if [[ "$server_ip" != "unknown" ]]; then
        print_success "External IP: $server_ip"
    else
        print_warning "Could not determine external IP"
    fi
    
    # Check HTTP access
    if curl -f http://localhost >/dev/null 2>&1; then
        print_success "HTTP access working"
    else
        print_warning "HTTP access not working"
    fi
    
    # Check HTTPS access (if configured)
    if curl -f https://localhost >/dev/null 2>&1; then
        print_success "HTTPS access working"
    else
        print_warning "HTTPS access not configured or not working"
    fi
    
    echo ""
}

# Check SSL Certificate (if configured)
check_ssl() {
    print_status "Checking SSL Certificate..."
    
    if command -v certbot >/dev/null 2>&1; then
        print_success "Certbot is installed"
        
        # Check certificates
        cert_info=$(sudo certbot certificates 2>/dev/null | grep "Certificate Name" || echo "No certificates found")
        if [[ "$cert_info" != "No certificates found" ]]; then
            print_success "SSL certificates found"
            echo "  $cert_info"
            
            # Check expiration
            expiry_info=$(sudo certbot certificates 2>/dev/null | grep "Expiry Date" || echo "")
            if [[ -n "$expiry_info" ]]; then
                echo "  $expiry_info"
            fi
        else
            print_warning "No SSL certificates configured"
        fi
    else
        print_warning "Certbot not installed (SSL not configured)"
    fi
    
    echo ""
}

# Check Firewall
check_firewall() {
    print_status "Checking Firewall..."
    
    if command -v ufw >/dev/null 2>&1; then
        if ufw status | grep -q "Status: active"; then
            print_success "UFW firewall is active"
            
            # Check if required ports are open
            if ufw status | grep -q "22/tcp"; then
                print_success "SSH port (22) is open"
            else
                print_warning "SSH port (22) might not be configured"
            fi
            
            if ufw status | grep -q "80/tcp"; then
                print_success "HTTP port (80) is open"
            else
                print_warning "HTTP port (80) might not be configured"
            fi
            
            if ufw status | grep -q "443/tcp"; then
                print_success "HTTPS port (443) is open"
            else
                print_warning "HTTPS port (443) might not be configured"
            fi
        else
            print_warning "UFW firewall is not active"
        fi
    else
        print_warning "UFW not installed"
    fi
    
    echo ""
}

# Check Log Files
check_logs() {
    print_status "Checking Log Files..."
    
    # Application logs
    if [[ -d "/var/log/crypto-airdrop" ]]; then
        log_size=$(du -sh /var/log/crypto-airdrop 2>/dev/null | cut -f1)
        print_success "Application logs size: $log_size"
        
        # Check for recent errors
        error_count=$(grep -i error /var/log/crypto-airdrop/*.log 2>/dev/null | wc -l || echo "0")
        if [[ "$error_count" -gt 0 ]]; then
            print_warning "Found $error_count error entries in logs"
        else
            print_success "No recent errors in application logs"
        fi
    else
        print_warning "Application log directory not found"
    fi
    
    # Nginx logs
    if [[ -f "/var/log/nginx/error.log" ]]; then
        nginx_errors=$(tail -n 100 /var/log/nginx/error.log 2>/dev/null | grep "$(date '+%Y/%m/%d')" | wc -l || echo "0")
        if [[ "$nginx_errors" -gt 0 ]]; then
            print_warning "Found $nginx_errors nginx errors today"
        else
            print_success "No recent nginx errors"
        fi
    else
        print_warning "Nginx error log not found"
    fi
    
    echo ""
}

# Check File Permissions
check_permissions() {
    print_status "Checking File Permissions..."
    
    if [[ -d "$APP_DIR" ]]; then
        owner=$(stat -c '%U:%G' "$APP_DIR")
        if [[ "$owner" == "$APP_USER:$APP_USER" ]]; then
            print_success "Application directory ownership is correct"
        else
            print_warning "Application directory ownership: $owner (expected: $APP_USER:$APP_USER)"
        fi
        
        # Check .env file permissions
        if [[ -f "$APP_DIR/.env" ]]; then
            env_perms=$(stat -c '%a' "$APP_DIR/.env")
            if [[ "$env_perms" == "600" ]]; then
                print_success "Environment file permissions are secure"
            else
                print_warning "Environment file permissions: $env_perms (recommended: 600)"
            fi
        else
            print_warning "Environment file not found"
        fi
    else
        print_error "Application directory not found"
    fi
    
    echo ""
}

# Generate Summary Report
generate_summary() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                                HEALTH CHECK SUMMARY                          ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    print_status "System Information:"
    echo "• Hostname: $(hostname)"
    echo "• OS: $(cat /etc/os-release | grep PRETTY_NAME | cut -d'=' -f2 | tr -d '\"')"
    echo "• Uptime: $(uptime -p)"
    echo "• Current time: $(date)"
    echo ""
    
    print_status "Quick Actions:"
    echo "• View application logs: crypto-manage logs"
    echo "• Restart application: crypto-manage restart"
    echo "• Check application status: crypto-manage status"
    echo "• Update application: crypto-manage update"
    echo "• Create backup: crypto-manage backup"
    
    echo ""
    print_success "Health check completed!"
}

# Main execution
main() {
    check_system_resources
    check_postgresql
    check_nginx
    check_application
    check_network
    check_ssl
    check_firewall
    check_logs
    check_permissions
    generate_summary
}

# Run main function
main "$@"