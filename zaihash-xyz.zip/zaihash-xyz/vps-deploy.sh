#!/bin/bash

# One-Click VPS Deployment for Crypto Airdrop Platform
# Usage: curl -fsSL https://raw.githubusercontent.com/[repo]/main/vps-deploy.sh | sudo bash -s [domain]

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
DOMAIN="$1"
APP_NAME="crypto-airdrop"
APP_USER="crypto"
APP_DIR="/opt/$APP_NAME"
NODE_VERSION="20"

print_status() { echo -e "${BLUE}[INFO]${NC} $1"; }
print_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "This script must be run as root (use sudo)"
        exit 1
    fi
}

# Detect OS
detect_os() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        OS=$ID
        VERSION=$VERSION_ID
    else
        print_error "Cannot detect OS. This script supports Ubuntu 20.04+ and Debian 11+"
        exit 1
    fi
    
    if [[ "$OS" != "ubuntu" && "$OS" != "debian" ]]; then
        print_error "Unsupported OS: $OS. This script supports Ubuntu 20.04+ and Debian 11+"
        exit 1
    fi
    
    print_success "Detected OS: $OS $VERSION"
}

# Update system
update_system() {
    print_status "Updating system packages..."
    apt-get update -y
    apt-get upgrade -y
    apt-get install -y curl wget git unzip software-properties-common apt-transport-https ca-certificates gnupg lsb-release
}

# Install Node.js
install_nodejs() {
    print_status "Installing Node.js $NODE_VERSION..."
    
    # Install Node.js using NodeSource repository
    curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash -
    apt-get install -y nodejs
    
    # Install PM2 globally
    npm install -g pm2
    
    print_success "Node.js $(node --version) installed"
    print_success "npm $(npm --version) installed"
    print_success "PM2 $(pm2 --version) installed"
}

# Install PostgreSQL
install_postgresql() {
    print_status "Installing PostgreSQL..."
    
    apt-get install -y postgresql postgresql-contrib
    
    # Start and enable PostgreSQL
    systemctl start postgresql
    systemctl enable postgresql
    
    print_success "PostgreSQL installed and started"
}

# Install Nginx
install_nginx() {
    print_status "Installing Nginx..."
    
    apt-get install -y nginx
    
    # Start and enable Nginx
    systemctl start nginx
    systemctl enable nginx
    
    print_success "Nginx installed and started"
}

# Setup firewall
setup_firewall() {
    print_status "Configuring firewall..."
    
    # Install and configure UFW
    apt-get install -y ufw
    
    # Reset firewall rules
    ufw --force reset
    
    # Set default policies
    ufw default deny incoming
    ufw default allow outgoing
    
    # Allow SSH
    ufw allow ssh
    
    # Allow HTTP and HTTPS
    ufw allow 80/tcp
    ufw allow 443/tcp
    
    # Enable firewall
    ufw --force enable
    
    print_success "Firewall configured"
}

# Create application user
create_app_user() {
    print_status "Creating application user..."
    
    if ! id "$APP_USER" &>/dev/null; then
        useradd -r -s /bin/bash -d "$APP_DIR" -m "$APP_USER"
        print_success "User $APP_USER created"
    else
        print_warning "User $APP_USER already exists"
    fi
}

# Setup database
setup_database() {
    print_status "Setting up database..."
    
    # Generate secure password
    DB_PASSWORD=$(openssl rand -hex 16)
    
    # Create database and user
    sudo -u postgres psql << EOF
CREATE DATABASE crypto_airdrop_db;
CREATE USER crypto_user WITH ENCRYPTED PASSWORD '$DB_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE crypto_airdrop_db TO crypto_user;
ALTER USER crypto_user CREATEDB;
\q
EOF
    
    # Store database credentials
    echo "DB_PASSWORD=$DB_PASSWORD" >> "$APP_DIR/.env"
    echo "DATABASE_URL=postgresql://crypto_user:$DB_PASSWORD@localhost:5432/crypto_airdrop_db" >> "$APP_DIR/.env"
    
    print_success "Database configured"
}

# Clone and setup application
setup_application() {
    print_status "Setting up application..."
    
    # Create application directory
    mkdir -p "$APP_DIR"
    cd "$APP_DIR"
    
    # Clone repository (replace with actual repo URL)
    # git clone https://github.com/yourusername/crypto-airdrop.git .
    
    # For now, create placeholder structure
    mkdir -p client server db shared
    
    # Generate environment variables
    SESSION_SECRET=$(openssl rand -hex 32)
    echo "NODE_ENV=production" >> .env
    echo "PORT=5000" >> .env
    echo "SESSION_SECRET=$SESSION_SECRET" >> .env
    
    # Set ownership
    chown -R "$APP_USER:$APP_USER" "$APP_DIR"
    
    print_success "Application setup complete"
}

# Install dependencies and build
build_application() {
    print_status "Installing dependencies and building application..."
    
    cd "$APP_DIR"
    
    # Switch to app user for npm operations
    sudo -u "$APP_USER" bash << 'EOF'
npm install
npm run build
EOF
    
    print_success "Application built successfully"
}

# Setup PM2 ecosystem
setup_pm2() {
    print_status "Setting up PM2 process manager..."
    
    cat > "$APP_DIR/ecosystem.config.js" << 'EOF'
module.exports = {
  apps: [{
    name: 'crypto-airdrop',
    script: 'server/index.js',
    cwd: '/opt/crypto-airdrop',
    instances: 'max',
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    error_file: '/var/log/crypto-airdrop/error.log',
    out_file: '/var/log/crypto-airdrop/out.log',
    log_file: '/var/log/crypto-airdrop/combined.log',
    time: true,
    autorestart: true,
    max_restarts: 10,
    min_uptime: '10s',
    max_memory_restart: '1G'
  }]
};
EOF
    
    # Create log directory
    mkdir -p /var/log/crypto-airdrop
    chown -R "$APP_USER:$APP_USER" /var/log/crypto-airdrop
    
    # Setup PM2 startup script
    sudo -u "$APP_USER" pm2 startup
    pm2 startup systemd -u "$APP_USER" --hp "$APP_DIR"
    
    print_success "PM2 configured"
}

# Configure Nginx
configure_nginx() {
    print_status "Configuring Nginx..."
    
    # Remove default site
    rm -f /etc/nginx/sites-enabled/default
    
    # Create application config
    cat > "/etc/nginx/sites-available/$APP_NAME" << EOF
server {
    listen 80;
    server_name ${DOMAIN:-_};
    
    # Security headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
    
    # Gzip compression
    gzip on;
    gzip_vary on;
    gzip_min_length 10240;
    gzip_proxied expired no-cache no-store private must-revalidate auth;
    gzip_types text/plain text/css text/xml text/javascript application/x-javascript application/xml+rss application/javascript;
    
    # Rate limiting
    limit_req_zone \$binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone \$binary_remote_addr zone=login:10m rate=1r/s;
    
    # Main application
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400;
    }
    
    # API rate limiting
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
    
    # Login rate limiting
    location /api/auth/ {
        limit_req zone=login burst=5 nodelay;
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # Health check
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
EOF
    
    # Enable site
    ln -sf "/etc/nginx/sites-available/$APP_NAME" "/etc/nginx/sites-enabled/"
    
    # Test configuration
    nginx -t
    
    # Reload Nginx
    systemctl reload nginx
    
    print_success "Nginx configured"
}

# Setup SSL with Let's Encrypt
setup_ssl() {
    if [[ -n "$DOMAIN" ]]; then
        print_status "Setting up SSL certificate for $DOMAIN..."
        
        # Install Certbot
        apt-get install -y certbot python3-certbot-nginx
        
        # Obtain certificate
        certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos --email "admin@$DOMAIN" --redirect
        
        # Setup auto-renewal
        echo "0 12 * * * /usr/bin/certbot renew --quiet" | crontab -
        
        print_success "SSL certificate configured for $DOMAIN"
    else
        print_warning "No domain provided. SSL not configured. Access via HTTP only."
    fi
}

# Start application
start_application() {
    print_status "Starting application..."
    
    cd "$APP_DIR"
    
    # Start with PM2
    sudo -u "$APP_USER" pm2 start ecosystem.config.js
    sudo -u "$APP_USER" pm2 save
    
    print_success "Application started"
}

# Create management script
create_management_script() {
    print_status "Creating management script..."
    
    cat > "/usr/local/bin/crypto-manage" << 'EOF'
#!/bin/bash

APP_DIR="/opt/crypto-airdrop"
APP_USER="crypto"

case "$1" in
    start)
        echo "Starting Crypto Airdrop Platform..."
        sudo -u $APP_USER pm2 start $APP_DIR/ecosystem.config.js
        ;;
    stop)
        echo "Stopping Crypto Airdrop Platform..."
        sudo -u $APP_USER pm2 stop crypto-airdrop
        ;;
    restart)
        echo "Restarting Crypto Airdrop Platform..."
        sudo -u $APP_USER pm2 restart crypto-airdrop
        ;;
    status)
        sudo -u $APP_USER pm2 status
        ;;
    logs)
        sudo -u $APP_USER pm2 logs crypto-airdrop
        ;;
    update)
        echo "Updating application..."
        cd $APP_DIR
        sudo -u $APP_USER git pull
        sudo -u $APP_USER npm install
        sudo -u $APP_USER npm run build
        sudo -u $APP_USER pm2 restart crypto-airdrop
        echo "Update complete"
        ;;
    backup)
        echo "Creating backup..."
        sudo -u postgres pg_dump crypto_airdrop_db > "/tmp/crypto-airdrop-backup-$(date +%Y%m%d_%H%M%S).sql"
        echo "Backup created in /tmp/"
        ;;
    *)
        echo "Usage: crypto-manage {start|stop|restart|status|logs|update|backup}"
        exit 1
        ;;
esac
EOF
    
    chmod +x /usr/local/bin/crypto-manage
    
    print_success "Management script created at /usr/local/bin/crypto-manage"
}

# Display final information
display_success() {
    local server_ip=$(curl -s ifconfig.me 2>/dev/null || echo "YOUR_SERVER_IP")
    
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║                        VPS DEPLOYMENT SUCCESSFUL!                           ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${BLUE}🚀 Your Crypto Airdrop Platform is now live!${NC}"
    echo ""
    
    if [[ -n "$DOMAIN" ]]; then
        echo -e "${BLUE}Access your application:${NC}"
        echo "• HTTPS URL: https://$DOMAIN"
        echo "• HTTP URL: http://$DOMAIN (redirects to HTTPS)"
    else
        echo -e "${BLUE}Access your application:${NC}"
        echo "• HTTP URL: http://$server_ip"
    fi
    
    echo ""
    echo -e "${BLUE}Management Commands:${NC}"
    echo "• Start: crypto-manage start"
    echo "• Stop: crypto-manage stop"
    echo "• Restart: crypto-manage restart"
    echo "• Status: crypto-manage status"
    echo "• Logs: crypto-manage logs"
    echo "• Update: crypto-manage update"
    echo "• Backup: crypto-manage backup"
    
    echo ""
    echo -e "${BLUE}Configuration Files:${NC}"
    echo "• Application: $APP_DIR"
    echo "• Environment: $APP_DIR/.env"
    echo "• Nginx: /etc/nginx/sites-available/$APP_NAME"
    echo "• PM2: $APP_DIR/ecosystem.config.js"
    echo "• Logs: /var/log/crypto-airdrop/"
    
    echo ""
    echo -e "${BLUE}System Services:${NC}"
    echo "• Application: PM2 (crypto-airdrop)"
    echo "• Database: PostgreSQL"
    echo "• Web Server: Nginx"
    echo "• Firewall: UFW"
    
    if [[ -n "$DOMAIN" ]]; then
        echo "• SSL: Let's Encrypt (auto-renewal enabled)"
    fi
    
    echo ""
    echo -e "${GREEN}✅ Setup complete! Your platform is ready for use.${NC}"
}

# Main execution
main() {
    echo -e "${BLUE}╔══════════════════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                    VPS Deployment for Crypto Airdrop Platform               ║${NC}"
    echo -e "${BLUE}║                              One-Click Setup                                ║${NC}"
    echo -e "${BLUE}╚══════════════════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    check_root
    detect_os
    update_system
    install_nodejs
    install_postgresql
    install_nginx
    setup_firewall
    create_app_user
    setup_database
    setup_application
    # build_application  # Uncomment when actual repo is available
    setup_pm2
    configure_nginx
    setup_ssl
    # start_application  # Uncomment when actual repo is available
    create_management_script
    display_success
}

# Run main function
main "$@"