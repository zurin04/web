import express, { type Express, type Request, type Response, type NextFunction } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { getCryptoPrices } from "./crypto-api";
import { WebSocketServer, WebSocket } from "ws";
import multer from "multer";
import path from "path";
import fs from "fs";
import crypto from "crypto";

// Define types for WebSocket server
interface ExtendedWebSocket extends WebSocket {
  isAlive: boolean;
}

type ChatMessage = {
  user: string;
  message: string;
  timestamp: string;
  isAdmin: boolean;
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Create HTTP server
  const httpServer = createServer(app);
  
  // Set up authentication routes
  setupAuth(app);

  // Chat message storage
  let chatMessages: ChatMessage[] = [];
  
  //------------------------------------------------------
  // WebSocket setup for chat
  //------------------------------------------------------
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Count of connected clients
  let onlineUsers = 0;
  
  // Heartbeat mechanism to detect disconnected clients
  const heartbeatInterval = setInterval(() => {
    wss.clients.forEach((client) => {
      const ws = client as ExtendedWebSocket;
      if (ws.isAlive === false) return ws.terminate();
      
      ws.isAlive = false;
      ws.ping();
    });
  }, 30000);
  
  wss.on('close', () => {
    clearInterval(heartbeatInterval);
  });
  
  wss.on('connection', (websocket) => {
    console.log('WebSocket connection established');
    const ws = websocket as ExtendedWebSocket;
    ws.isAlive = true;
    onlineUsers++;
    
    console.log(`Active connections: ${onlineUsers}`);
    
    // Send the current status to the new client
    ws.send(JSON.stringify({ 
      type: 'status', 
      online: onlineUsers 
    }));
    
    // Send message history to the new client
    ws.send(JSON.stringify({
      type: 'history',
      messages: chatMessages.slice(-50) // Send last 50 messages
    }));
    
    // Broadcast updated user count to all clients
    wss.clients.forEach((client) => {
      if (client !== ws && client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({ 
          type: 'status', 
          online: onlineUsers 
        }));
      }
    });
    
    ws.on('pong', () => {
      ws.isAlive = true;
    });
    
    ws.on('message', (message) => {
      console.log('WebSocket message received:', message.toString());
      try {
        const data = JSON.parse(message.toString());
        console.log('Parsed message:', data);
        
        if (data.type === 'message') {
          console.log('Chat message from:', data.payload.user);
          // Store new message
          chatMessages.push(data.payload);
          
          // Keep only the last 200 messages
          if (chatMessages.length > 200) {
            chatMessages = chatMessages.slice(-200);
          }
          
          // Broadcast to all connected clients
          wss.clients.forEach((client) => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'message',
                payload: data.payload
              }));
            }
          });
          console.log('Message broadcast to all clients');
        }
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
      }
    });
    
    ws.on('close', () => {
      onlineUsers = Math.max(0, onlineUsers - 1);
      
      // Broadcast updated user count
      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify({ 
            type: 'status', 
            online: onlineUsers 
          }));
        }
      });
    });
  });

  //------------------------------------------------------
  // API Routes
  //------------------------------------------------------
  
  // Wallet authentication routes
  app.get("/api/wallet/nonce", async (req, res) => {
    try {
      const address = req.query.address as string;
      
      if (!address) {
        return res.status(400).json({ message: "Wallet address is required" });
      }
      
      // Generate and store nonce for this address
      const nonce = await storage.generateNonce(address);
      res.json({ nonce });
    } catch (error) {
      console.error("Error generating nonce:", error);
      res.status(500).json({ message: "Failed to generate nonce" });
    }
  });
  
  // Airdrops routes
  
  // Get all airdrops
  app.get("/api/airdrops", async (req, res) => {
    try {
      const airdrops = await storage.getAllAirdrops();
      res.json(airdrops);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch airdrops" });
    }
  });
  
  // Get featured airdrops
  app.get("/api/airdrops/featured", async (req, res) => {
    try {
      const airdrops = await storage.getFeaturedAirdrops();
      res.json(airdrops);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch featured airdrops" });
    }
  });
  
  // Get airdrop by ID
  app.get("/api/airdrops/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid airdrop ID" });
      }
      
      const airdrop = await storage.getAirdropById(id);
      if (!airdrop) {
        return res.status(404).json({ message: "Airdrop not found" });
      }
      
      // Increment view count
      await storage.incrementAirdropViews(id);
      
      res.json(airdrop);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch airdrop" });
    }
  });
  
  // Save airdrop to user's saved list
  app.post("/api/airdrops/:id/save", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to save airdrops" });
    }
    
    try {
      const airdropId = parseInt(req.params.id);
      if (isNaN(airdropId)) {
        return res.status(400).json({ message: "Invalid airdrop ID" });
      }
      
      const airdrop = await storage.getAirdropById(airdropId);
      if (!airdrop) {
        return res.status(404).json({ message: "Airdrop not found" });
      }
      
      const userId = req.user.id;
      await storage.toggleSavedAirdrop(userId, airdropId);
      
      res.status(200).json({ message: "Airdrop saved status toggled" });
    } catch (error) {
      res.status(500).json({ message: "Failed to save airdrop" });
    }
  });
  
  // Mark airdrop as complete
  app.post("/api/airdrops/:id/complete", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to mark airdrops as complete" });
    }
    
    try {
      const airdropId = parseInt(req.params.id);
      if (isNaN(airdropId)) {
        return res.status(400).json({ message: "Invalid airdrop ID" });
      }
      
      const airdrop = await storage.getAirdropById(airdropId);
      if (!airdrop) {
        return res.status(404).json({ message: "Airdrop not found" });
      }
      
      const userId = req.user.id;
      await storage.toggleCompletedAirdrop(userId, airdropId);
      
      res.status(200).json({ message: "Airdrop completion status toggled" });
    } catch (error) {
      res.status(500).json({ message: "Failed to mark airdrop as complete" });
    }
  });
  
  // Cryptocurrency price routes
  app.get("/api/crypto/prices", async (req, res) => {
    try {
      const prices = await getCryptoPrices();
      res.json(prices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch cryptocurrency prices" });
    }
  });
  
  // Newsletter subscription
  app.post("/api/newsletter/subscribe", async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return res.status(400).json({ message: "Valid email is required" });
      }
      
      await storage.subscribeToNewsletter(email);
      res.status(200).json({ message: "Successfully subscribed to newsletter" });
    } catch (error) {
      res.status(500).json({ message: "Failed to subscribe to newsletter" });
    }
  });
  
  // Get newsletter subscribers (admin only)
  app.get("/api/newsletter/subscribers", isAdmin, async (req, res) => {
    try {
      const subscribers = await storage.getNewsletterSubscribers();
      res.status(200).json(subscribers);
    } catch (error) {
      console.error("Error fetching newsletter subscribers:", error);
      res.status(500).json({ message: "Failed to fetch newsletter subscribers" });
    }
  });
  
  // Export newsletter subscribers as CSV (admin only)
  app.get("/api/newsletter/export", isAdmin, async (req, res) => {
    try {
      const subscribers = await storage.getNewsletterSubscribers();
      
      // Generate CSV content
      let csvContent = "Email,Subscribed Date\n";
      subscribers.forEach(subscriber => {
        csvContent += `"${subscriber.email}","${new Date(subscriber.subscribed_at).toISOString()}"\n`;
      });
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="newsletter_subscribers.csv"');
      res.status(200).send(csvContent);
    } catch (error) {
      console.error("Error exporting newsletter subscribers:", error);
      res.status(500).json({ message: "Failed to export newsletter subscribers" });
    }
  });
  
  // Export user list as CSV (admin only)
  app.get("/api/users/export", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      
      // Generate CSV content
      let csvContent = "ID,Username,Wallet Address,Admin,Creator,Created Date\n";
      users.forEach(user => {
        csvContent += `"${user.id}","${user.username}","${user.wallet_address || ''}","${user.isAdmin ? 'Yes' : 'No'}","${user.isCreator ? 'Yes' : 'No'}","${new Date(user.created_at).toISOString()}"\n`;
      });
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="users.csv"');
      res.status(200).send(csvContent);
    } catch (error) {
      console.error("Error exporting users:", error);
      res.status(500).json({ message: "Failed to export users" });
    }
  });
  
  // Get member list (for admins only)
  app.get("/api/members", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      
      // Only share limited information about users
      const memberList = users.map(user => ({
        id: user.id,
        username: user.username,
        isAdmin: user.isAdmin,
        isCreator: user.isCreator,
        profile_image: user.profile_image,
        created_at: user.created_at
      }));
      
      res.json(memberList);
    } catch (error) {
      console.error("Error fetching members:", error);
      res.status(500).json({ message: "Failed to fetch members" });
    }
  });
  
  // Export member list as CSV (for admins only)
  app.get("/api/members/export", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      
      // Generate CSV with member information
      let csvContent = "ID,Username,Role,Wallet Address,Joined Date\n";
      users.forEach(user => {
        const role = user.isAdmin ? "Admin" : (user.isCreator ? "Creator" : "Member");
        csvContent += `"${user.id}","${user.username}","${role}","${user.wallet_address || ''}","${new Date(user.created_at).toISOString()}"\n`;
      });
      
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="members.csv"');
      res.status(200).send(csvContent);
    } catch (error) {
      console.error("Error exporting members:", error);
      res.status(500).json({ message: "Failed to export members" });
    }
  });
  
  // User profile update routes
  app.put("/api/user/profile", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in" });
    }
    
    try {
      const userId = req.user.id;
      const { username, twitter_handle, discord_handle, telegram_handle, profile_image } = req.body;
      
      // If username is being changed, check if it's already taken
      if (username && username !== req.user.username) {
        const existingUser = await storage.getUserByUsername(username);
        if (existingUser && existingUser.id !== userId) {
          return res.status(400).json({ message: "Username already exists" });
        }
      }
      
      const updatedUser = await storage.updateUser(userId, {
        username,
        twitter_handle,
        discord_handle,
        telegram_handle,
        profile_image
      });
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });
  
  // Profile image upload route
  app.post("/api/user/profile-image", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in" });
    }
    
    try {
      const { image_url } = req.body;
      
      if (!image_url) {
        return res.status(400).json({ message: "Image URL is required" });
      }
      
      // Validate URL format
      try {
        new URL(image_url);
      } catch (e) {
        return res.status(400).json({ message: "Invalid URL format" });
      }
      
      const userId = req.user.id;
      const updatedUser = await storage.updateUser(userId, {
        profile_image: image_url
      });
      
      res.json({ success: true, profile_image: updatedUser.profile_image });
    } catch (error) {
      console.error("Error uploading profile image:", error);
      res.status(500).json({ message: "Failed to upload profile image" });
    }
  });
  
  // Get user profile image by username
  app.get("/api/users/profile-image/:username", async (req, res) => {
    try {
      const username = req.params.username;
      const user = await storage.getUserByUsername(username);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ 
        profile_image: user.profile_image || null 
      });
    } catch (error) {
      console.error("Error fetching user profile image:", error);
      res.status(500).json({ message: "Server error" });
    }
  });

  // User password update
  app.put("/api/user/password", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in" });
    }
    
    try {
      const userId = req.user.id;
      const { currentPassword, newPassword } = req.body;
      
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Current and new passwords are required" });
      }
      
      if (newPassword.length < 6) {
        return res.status(400).json({ message: "Password must be at least 6 characters long" });
      }
      
      const success = await storage.updateUserPassword(userId, currentPassword, newPassword);
      
      if (!success) {
        return res.status(400).json({ message: "Current password is incorrect" });
      }
      
      res.json({ message: "Password updated successfully" });
    } catch (error) {
      console.error("Error updating password:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to update password" 
      });
    }
  });
  
  //------------------------------------------------------
  // Admin Middleware
  //------------------------------------------------------
  
  // Middleware to check if user is admin
  function isAdmin(req: Request, res: Response, next: NextFunction) {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in" });
    }
    
    if (!req.user?.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }
    
    next();
  }
  
  //------------------------------------------------------
  // File Upload Configuration
  //------------------------------------------------------
  
  // Set up file uploads with Multer
  // Ensure upload directories exist
  const uploadDir = path.join(process.cwd(), 'public/uploads');
  const imageUploadDir = path.join(uploadDir, 'images');
  
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }
  if (!fs.existsSync(imageUploadDir)) {
    fs.mkdirSync(imageUploadDir, { recursive: true });
  }
  
  // Configure storage for file uploads
  const multerStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, imageUploadDir);
    },
    filename: (req, file, cb) => {
      // Generate unique filename with original extension
      const uniquePrefix = crypto.randomBytes(16).toString('hex');
      const ext = path.extname(file.originalname);
      cb(null, `${uniquePrefix}${ext}`);
    }
  });
  
  // File filter to only allow image files
  const fileFilter = (req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  };
  
  const upload = multer({ 
    storage: multerStorage,
    fileFilter,
    limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
  });
  
  // Serve uploaded files statically
  app.use('/uploads', express.static(path.join(process.cwd(), 'public/uploads')));
  
  // File upload route for profile images
  app.post("/api/upload/profile-image", upload.single('image'), async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in" });
    }
    
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const imageUrl = `/uploads/images/${req.file.filename}`;
      const userId = req.user.id;
      
      // Update the user's profile image
      const updatedUser = await storage.updateUser(userId, {
        profile_image: imageUrl
      });
      
      res.json({ 
        success: true, 
        profile_image: imageUrl
      });
    } catch (error) {
      console.error("Error uploading profile image:", error);
      res.status(500).json({ message: "Failed to upload profile image" });
    }
  });
  

  
  // File upload route for site logo - admin only
  app.post("/api/admin/upload/site-logo", isAdmin, upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const imageUrl = `/uploads/images/${req.file.filename}`;
      
      // Update site settings with the new logo
      const updatedSettings = await storage.updateSiteSettings({
        logo_url: imageUrl
      });
      
      res.json({ 
        success: true, 
        logo_url: imageUrl
      });
    } catch (error) {
      console.error("Error uploading site logo:", error);
      res.status(500).json({ message: "Failed to upload site logo" });
    }
  });
  
  // File upload route for site banner - admin only
  app.post("/api/admin/upload/site-banner", isAdmin, upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const imageUrl = `/uploads/images/${req.file.filename}`;
      
      // Update site settings with the new banner
      const updatedSettings = await storage.updateSiteSettings({
        banner_url: imageUrl
      });
      
      res.json({ 
        success: true, 
        banner_url: imageUrl
      });
    } catch (error) {
      console.error("Error uploading site banner:", error);
      res.status(500).json({ message: "Failed to upload site banner" });
    }
  });
  
  // File upload route for airdrop steps images - admin only
  app.post("/api/admin/upload/airdrop-image", isAdmin, upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const imageUrl = `/uploads/images/${req.file.filename}`;
      
      res.json({ 
        success: true, 
        image_url: imageUrl
      });
    } catch (error) {
      console.error("Error uploading airdrop step image:", error);
      res.status(500).json({ message: "Failed to upload airdrop step image" });
    }
  });
  
  // File upload route for airdrop images - available to creators and admins
  app.post("/api/upload/airdrop-image", isAdminOrCreator, upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const imageUrl = `/uploads/images/${req.file.filename}`;
      
      res.json({ 
        success: true, 
        image_url: imageUrl
      });
    } catch (error) {
      console.error("Error uploading airdrop image:", error);
      res.status(500).json({ message: "Failed to upload airdrop image" });
    }
  });
  
  //------------------------------------------------------
  // Admin Routes
  //------------------------------------------------------
  
  // Get all users (admin view)
  app.get("/api/admin/users", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  // Create new user (admin only)
  app.post("/api/admin/users", isAdmin, async (req, res) => {
    try {
      const { username, password, isAdmin } = req.body;
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      // Create the new user with admin status
      const newUser = await storage.createUserWithPassword({
        username,
        password,
        isAdmin: Boolean(isAdmin),
      });
      
      // Return the user without password
      const { password: _, ...userWithoutPassword } = newUser;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ message: "Failed to create user" });
    }
  });
  
  // Update user admin status
  app.patch("/api/admin/users/:id/admin-status", isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const { isAdmin: newAdminStatus } = req.body;
      
      // Make sure the user exists
      const user = await storage.getUser(userId);
      
      // Update admin status
      const updatedUser = await storage.updateUser(userId, {
        isAdmin: Boolean(newAdminStatus)
      });
      
      // Return the updated user
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error updating user admin status:", error);
      res.status(500).json({ message: "Failed to update user admin status" });
    }
  });
  
  // Admin: Directly promote user to creator
  app.post("/api/admin/users/:id/promote-creator", isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Promote user to creator
      try {
        const updatedUser = await storage.promoteToCreator(userId);
        
        // Return the updated user (without password)
        const { password, ...userWithoutPassword } = updatedUser;
        res.json(userWithoutPassword);
      } catch (error: any) {
        return res.status(400).json({ message: error.message || "Failed to promote user to creator" });
      }
    } catch (error) {
      console.error("Error promoting user to creator:", error);
      res.status(500).json({ message: "Failed to promote user to creator" });
    }
  });

  // Admin: Revoke creator status
  app.post("/api/admin/users/:id/revoke-creator", isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Revoke creator status
      try {
        const updatedUser = await storage.revokeCreatorStatus(userId);
        
        // Return the updated user (without password)
        const { password, ...userWithoutPassword } = updatedUser;
        res.json(userWithoutPassword);
      } catch (error: any) {
        return res.status(400).json({ message: error.message || "Failed to revoke creator status" });
      }
    } catch (error) {
      console.error("Error revoking creator status:", error);
      res.status(500).json({ message: "Failed to revoke creator status" });
    }
  });
  
  // Get all airdrops (admin view)
  app.get("/api/admin/airdrops", isAdmin, async (req, res) => {
    try {
      const airdrops = await storage.getAllAirdrops();
      res.json(airdrops);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch airdrops" });
    }
  });
  
  // Function to check if user is admin or creator
  function isAdminOrCreator(req: Request, res: Response, next: NextFunction) {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    // TypeScript type guard to ensure req.user is not undefined
    if (req.user && (req.user.isAdmin || req.user.isCreator)) {
      return next();
    }
    
    return res.status(403).json({ message: "You need creator privileges to perform this action" });
  }

  // Create new airdrop (admin or creator)
  app.post("/api/airdrops", isAdminOrCreator, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Add the user who posted it
      const airdropData = {
        ...req.body,
        posted_by: req.user.username
      };
      
      const airdrop = await storage.createAirdrop(airdropData);
      res.status(201).json(airdrop);
    } catch (error) {
      console.error("Failed to create airdrop:", error);
      res.status(500).json({ message: "Failed to create airdrop" });
    }
  });
  
  // Admin route for backwards compatibility
  app.post("/api/admin/airdrops", isAdmin, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Add the user who posted it
      const airdropData = {
        ...req.body,
        posted_by: req.user.username
      };
      
      const airdrop = await storage.createAirdrop(airdropData);
      res.status(201).json(airdrop);
    } catch (error) {
      console.error("Failed to create airdrop:", error);
      res.status(500).json({ message: "Failed to create airdrop" });
    }
  });
  
  // Update airdrop (admin or creator owner)
  app.put("/api/airdrops/:id", isAdminOrCreator, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid airdrop ID" });
      }
      
      // Get the airdrop to check ownership
      const existingAirdrop = await storage.getAirdropById(id);
      if (!existingAirdrop) {
        return res.status(404).json({ message: "Airdrop not found" });
      }
      
      // Only allow admins or the original creator to update
      if (!req.user.isAdmin && existingAirdrop.posted_by !== req.user.username) {
        return res.status(403).json({ message: "You can only edit airdrops you created" });
      }
      
      const airdrop = await storage.updateAirdrop(id, req.body);
      res.json(airdrop);
    } catch (error) {
      console.error("Failed to update airdrop:", error);
      res.status(500).json({ message: "Failed to update airdrop" });
    }
  });
  
  // Admin route for backwards compatibility
  app.put("/api/admin/airdrops/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid airdrop ID" });
      }
      
      const airdrop = await storage.updateAirdrop(id, req.body);
      if (!airdrop) {
        return res.status(404).json({ message: "Airdrop not found" });
      }
      
      res.json(airdrop);
    } catch (error) {
      res.status(500).json({ message: "Failed to update airdrop" });
    }
  });
  
  // Delete airdrop (admin or creator owner)
  app.delete("/api/airdrops/:id", isAdminOrCreator, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid airdrop ID" });
      }
      
      // Get the airdrop to check ownership
      const existingAirdrop = await storage.getAirdropById(id);
      if (!existingAirdrop) {
        return res.status(404).json({ message: "Airdrop not found" });
      }
      
      // Only allow admins or the original creator to delete
      if (!req.user.isAdmin && existingAirdrop.posted_by !== req.user.username) {
        return res.status(403).json({ message: "You can only delete airdrops you created" });
      }
      
      await storage.deleteAirdrop(id);
      res.status(200).json({ message: "Airdrop deleted successfully" });
    } catch (error) {
      console.error("Failed to delete airdrop:", error);
      res.status(500).json({ message: "Failed to delete airdrop" });
    }
  });
  
  // Admin route for backwards compatibility
  app.delete("/api/admin/airdrops/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid airdrop ID" });
      }
      
      await storage.deleteAirdrop(id);
      res.status(200).json({ message: "Airdrop deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete airdrop" });
    }
  });
  
  //------------------------------------------------------
  // Creator Applications Routes
  //------------------------------------------------------
  
  // Admin routes for creator applications are defined below
  
  // Get current user's creator applications
  app.get("/api/creator-applications/user", async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const applications = await storage.getUserCreatorApplications(req.user.id);
      res.json(applications);
    } catch (error) {
      console.error("Error fetching user creator applications:", error);
      res.status(500).json({ message: "Failed to fetch creator applications" });
    }
  });
  
  // Create new creator application
  app.post("/api/creator-applications", async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      // Check if user already has a pending application
      const userApplications = await storage.getUserCreatorApplications(req.user.id);
      const pendingApplications = userApplications.filter(
        app => ['pending', 'payment_pending'].includes(app.status)
      );
      
      if (pendingApplications.length > 0) {
        return res.status(400).json({ message: "You already have a pending application" });
      }
      
      // Create application with payment_pending status to show payment details immediately
      const application = await storage.createCreatorApplication({
        user_id: req.user.id,
        reason: req.body.reason,
        status: 'payment_pending', // Start with payment_pending to show payment info
        created_at: new Date(),
        updated_at: new Date()
      });
      
      res.status(201).json(application);
    } catch (error) {
      console.error("Error creating creator application:", error);
      res.status(500).json({ message: "Failed to create creator application" });
    }
  });
  
  // Submit payment proof for creator application
  app.post("/api/creator-applications/:id/payment", async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const applicationId = parseInt(req.params.id);
      if (isNaN(applicationId)) {
        return res.status(400).json({ message: "Invalid application ID" });
      }
      
      // Verify application belongs to the user
      const application = await storage.getCreatorApplicationById(applicationId);
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      if (application.user_id !== req.user.id) {
        return res.status(403).json({ message: "Not authorized to update this application" });
      }
      
      // Verify application is in payment_pending status
      if (application.status !== 'payment_pending') {
        return res.status(400).json({ message: "This application is not awaiting payment" });
      }
      
      // Update application with payment details but don't verify automatically
      const { tx_hash, amount, currency } = req.body;
      if (!tx_hash) {
        return res.status(400).json({ message: "Transaction hash is required" });
      }
      
      const updatedApplication = await storage.updateCreatorApplication(applicationId, {
        payment_tx_hash: tx_hash,
        payment_amount: amount,
        payment_currency: currency,
        status: 'pending_review',
        updated_at: new Date()
      });
      
      res.json(updatedApplication);
    } catch (error) {
      console.error("Error submitting payment proof:", error);
      res.status(500).json({ message: "Failed to submit payment proof" });
    }
  });
  
  // Admin: Approve creator application
  app.post("/api/admin/creator-applications/:id/approve", isAdmin, async (req, res) => {
    try {
      const applicationId = parseInt(req.params.id);
      if (isNaN(applicationId)) {
        return res.status(400).json({ message: "Invalid application ID" });
      }
      
      // Verify application exists
      const application = await storage.getCreatorApplicationById(applicationId);
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      // Update application status
      const updatedApplication = await storage.updateCreatorApplication(applicationId, {
        status: 'approved',
        updated_at: new Date()
      });
      
      // Promote user to creator
      await storage.promoteToCreator(application.user_id);
      
      res.json(updatedApplication);
    } catch (error) {
      console.error("Error approving creator application:", error);
      res.status(500).json({ message: "Failed to approve creator application" });
    }
  });
  
  // Admin: Reject creator application
  app.post("/api/admin/creator-applications/:id/reject", isAdmin, async (req, res) => {
    try {
      const applicationId = parseInt(req.params.id);
      if (isNaN(applicationId)) {
        return res.status(400).json({ message: "Invalid application ID" });
      }
      
      // Verify application exists
      const application = await storage.getCreatorApplicationById(applicationId);
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      // Update application status
      const updatedApplication = await storage.updateCreatorApplication(applicationId, {
        status: 'rejected',
        reason: req.body.reason || "Application rejected by admin",
        updated_at: new Date()
      });
      
      res.json(updatedApplication);
    } catch (error) {
      console.error("Error rejecting creator application:", error);
      res.status(500).json({ message: "Failed to reject creator application" });
    }
  });
  
  //------------------------------------------------------
  // Categories API Routes
  //------------------------------------------------------
  
  // Get all categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });
  
  // Get category by ID
  app.get("/api/categories/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }
      
      const category = await storage.getCategoryById(id);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch category" });
    }
  });
  
  // Get airdrops by category
  app.get("/api/categories/:id/airdrops", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }
      
      const category = await storage.getCategoryById(id);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      const airdrops = await storage.getAirdropsByCategory(id);
      res.json(airdrops);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch airdrops for category" });
    }
  });
  
  // Admin category routes
  app.post("/api/admin/categories", isAdmin, async (req, res) => {
    try {
      const { name, description } = req.body;
      
      if (!name) {
        return res.status(400).json({ message: "Category name is required" });
      }
      
      const category = await storage.createCategory({
        name,
        description,
        created_at: new Date()
      });
      
      res.status(201).json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to create category" });
    }
  });
  
  app.put("/api/admin/categories/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }
      
      const { name, description } = req.body;
      
      if (!name) {
        return res.status(400).json({ message: "Category name is required" });
      }
      
      const category = await storage.updateCategory(id, {
        name,
        description
      });
      
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to update category" });
    }
  });
  
  app.delete("/api/admin/categories/:id", isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }
      
      await storage.deleteCategory(id);
      res.status(200).json({ message: "Category deleted successfully" });
    } catch (error) {
      if (error instanceof Error && error.message.includes("Cannot delete category with associated airdrops")) {
        return res.status(400).json({ message: error.message });
      }
      res.status(500).json({ message: "Failed to delete category" });
    }
  });
  
  //------------------------------------------------------
  // Site Settings API Routes
  //------------------------------------------------------
  
  // Get site settings
  app.get("/api/site-settings", async (req, res) => {
    try {
      const settings = await storage.getSiteSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch site settings" });
    }
  });
  
  // Update site settings (admin only)
  app.put("/api/admin/site-settings", isAdmin, async (req, res) => {
    try {
      const { 
        site_name, 
        site_description, 
        banner_url, 
        logo_url, 
        twitter_link, 
        discord_link, 
        telegram_link,
        creator_fee_currency,
        creator_fee_amount,
        creator_payment_address
      } = req.body;
      
      const settings = await storage.updateSiteSettings({
        site_name,
        site_description,
        banner_url,
        logo_url,
        twitter_link,
        discord_link,
        telegram_link,
        creator_fee_currency,
        creator_fee_amount,
        creator_payment_address
      });
      
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to update site settings" });
    }
  });

  //------------------------------------------------------
  // Creator Application Routes
  //------------------------------------------------------
  
  // Check if user is creator
  app.get("/api/user/creator-status", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in" });
    }
    
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      res.json({ 
        isCreator: user.isCreator,
        userId: user.id 
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to check creator status" });
    }
  });
  
  // Apply to become a creator
  app.post("/api/creator/apply", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in to apply" });
    }
    
    try {
      const userId = req.user.id;
      const { reason } = req.body;
      
      // Check if user already has a pending application
      const existingApplications = await storage.getUserCreatorApplications(userId);
      const pendingApplication = existingApplications.find(app => 
        app.status === "pending" || app.status === "payment_pending"
      );
      
      if (pendingApplication) {
        return res.status(400).json({ 
          message: "You already have a pending application",
          application: pendingApplication
        });
      }
      
      // Create new application with payment_pending status to show payment details immediately
      const application = await storage.createCreatorApplication({
        user_id: userId,
        reason: reason || "",
        status: "payment_pending"
      });
      
      res.status(201).json(application);
    } catch (error) {
      console.error("Error applying for creator:", error);
      res.status(500).json({ message: "Failed to submit application" });
    }
  });
  
  // Get current user's creator applications
  app.get("/api/creator/applications", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in" });
    }
    
    try {
      const userId = req.user.id;
      const applications = await storage.getUserCreatorApplications(userId);
      
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch applications" });
    }
  });
  
  // Submit payment for creator application
  app.post("/api/creator/applications/:id/payment", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "You must be logged in" });
    }
    
    try {
      const applicationId = parseInt(req.params.id);
      const { txHash, amount, currency } = req.body;
      
      if (!txHash || !amount || !currency) {
        return res.status(400).json({ message: "Missing payment details" });
      }
      
      // Get application and verify it belongs to current user
      const application = await storage.getCreatorApplicationById(applicationId);
      
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      if (application.user_id !== req.user.id) {
        return res.status(403).json({ message: "You can only update your own applications" });
      }
      
      if (application.status !== "payment_pending") {
        return res.status(400).json({ 
          message: `Application is in ${application.status} state, not payment_pending` 
        });
      }
      
      // Process payment verification
      const updatedApplication = await storage.verifyCreatorPayment(
        applicationId, 
        txHash, 
        amount, 
        currency
      );
      
      res.json(updatedApplication);
    } catch (error) {
      console.error("Error verifying payment:", error);
      res.status(500).json({ message: "Failed to verify payment" });
    }
  });
  
  // Admin: Get all creator applications
  app.get("/api/admin/creator-applications", isAdmin, async (req, res) => {
    try {
      const applications = await storage.getCreatorApplications();
      res.json(applications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch applications" });
    }
  });
  
  // Admin: Update creator application status
  app.put("/api/admin/creator-applications/:id", isAdmin, async (req, res) => {
    try {
      const applicationId = parseInt(req.params.id);
      const { status, reason } = req.body;
      
      if (!status || !["pending", "payment_pending", "approved", "rejected"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      // Get application
      const application = await storage.getCreatorApplicationById(applicationId);
      
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      // Update application
      const updatedApplication = await storage.updateCreatorApplication(applicationId, {
        status,
        reason: reason || application.reason,
        reviewed_by: req.user ? req.user.id : undefined
      });
      
      // If status is approved, promote user to creator
      if (status === "approved") {
        await storage.promoteToCreator(application.user_id);
      }
      
      res.json(updatedApplication);
    } catch (error) {
      console.error("Error updating application:", error);
      res.status(500).json({ message: "Failed to update application" });
    }
  });

  //------------------------------------------------------
  // Health Check and System Status for Ubuntu Deployment
  //------------------------------------------------------
  
  // Simple health check endpoint
  app.get("/health", (req, res) => {
    res.status(200).send("healthy\n");
  });
  
  // Comprehensive system status for monitoring
  app.get("/api/system/status", async (req, res) => {
    const startTime = Date.now();
    
    try {
      interface ServiceStatus {
        name: string;
        status: string;
        connections?: number;
        message_history_size?: number;
        response_time?: number;
        error?: string;
      }

      const status: any = {
        status: "healthy",
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        version: process.version,
        environment: process.env.NODE_ENV || "development",
        port: process.env.PORT || 5000,
        websocket: {
          connections: onlineUsers,
          total_clients: wss.clients.size
        },
        database: {
          status: "unknown",
          response_time: null
        },
        services: []
      };

      // Test database connection
      try {
        const dbStartTime = Date.now();
        await storage.getSiteSettings(); // Simple DB query
        status.database.status = "connected";
        status.database.response_time = Date.now() - dbStartTime;
      } catch (dbError) {
        status.database.status = "error";
        status.database.error = dbError instanceof Error ? dbError.message : "Unknown database error";
      }

      // Add service checks
      status.services.push({
        name: "WebSocket Server",
        status: wss.clients.size > 0 ? "running" : "idle",
        connections: wss.clients.size
      });

      status.services.push({
        name: "Chat Service",
        status: "running",
        message_history_size: chatMessages.length
      });

      // Check crypto API if available
      try {
        const cryptoStartTime = Date.now();
        await getCryptoPrices();
        status.services.push({
          name: "Crypto Price API",
          status: "connected",
          response_time: Date.now() - cryptoStartTime
        });
      } catch (cryptoError) {
        status.services.push({
          name: "Crypto Price API",
          status: "error",
          error: cryptoError instanceof Error ? cryptoError.message : "API unavailable"
        });
      }

      // Calculate total response time
      status.response_time = Date.now() - startTime;

      // Determine overall health
      const hasErrors = status.database.status === "error" || 
                       status.services.some((s: any) => s.status === "error");
      
      if (hasErrors) {
        status.status = "degraded";
        res.status(503);
      }

      res.json(status);
    } catch (error) {
      res.status(500).json({
        status: "error",
        timestamp: new Date().toISOString(),
        error: error instanceof Error ? error.message : "System check failed",
        response_time: Date.now() - startTime
      });
    }
  });

  // System metrics for Ubuntu monitoring
  app.get("/api/system/metrics", (req, res) => {
    const metrics = {
      timestamp: new Date().toISOString(),
      process: {
        pid: process.pid,
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        cpu_usage: process.cpuUsage(),
        version: process.version,
        platform: process.platform,
        arch: process.arch
      },
      system: {
        load_average: process.platform === 'linux' ? require('os').loadavg() : null,
        free_memory: require('os').freemem(),
        total_memory: require('os').totalmem(),
        hostname: require('os').hostname(),
        uptime: require('os').uptime()
      },
      application: {
        environment: process.env.NODE_ENV || "development",
        port: process.env.PORT || 5000,
        websocket_connections: onlineUsers,
        chat_messages: chatMessages.length
      }
    };

    res.json(metrics);
  });

  return httpServer;
}
