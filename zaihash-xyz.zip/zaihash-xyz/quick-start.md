# Quick Start - Crypto Airdrop Platform

## 🚀 Deploy to VPS in 60 Seconds

### Option 1: Basic Deployment (HTTP)
```bash
curl -fsSL https://raw.githubusercontent.com/[your-repo]/main/vps-deploy.sh | sudo bash
```

### Option 2: With Custom Domain (HTTPS)
```bash
curl -fsSL https://raw.githubusercontent.com/[your-repo]/main/vps-deploy.sh | sudo bash -s your-domain.com
```

## 📋 Prerequisites

- **VPS Requirements**: Ubuntu 20.04+ or Debian 11+, 2GB RAM, 20GB storage
- **Access**: SSH root access to your VPS
- **Domain** (optional): For SSL/HTTPS setup

## 🛠️ What Gets Installed

✅ Node.js 20 + npm  
✅ PostgreSQL database  
✅ Nginx web server  
✅ PM2 process manager  
✅ UFW firewall  
✅ SSL certificates (if domain provided)  

## 🎯 Quick Commands

After deployment, manage your platform with:

```bash
crypto-manage start      # Start application
crypto-manage stop       # Stop application  
crypto-manage restart    # Restart application
crypto-manage status     # Check status
crypto-manage logs       # View logs
crypto-manage update     # Update from git
crypto-manage backup     # Create database backup
```

## 🔍 Health Check

Run comprehensive health check:
```bash
./health-check.sh
```

## 📍 Access Your Platform

- **With domain**: https://your-domain.com
- **Without domain**: http://your-server-ip

## 🆘 Need Help?

1. **Check status**: `crypto-manage status`
2. **View logs**: `crypto-manage logs`  
3. **Run health check**: `./health-check.sh`
4. **Restart services**: `crypto-manage restart`

## 📚 Full Documentation

For detailed setup, configuration, and troubleshooting, see [README-VPS-DEPLOY.md](README-VPS-DEPLOY.md).

---

**Ready to deploy?** Just run the one-liner command above on your VPS!